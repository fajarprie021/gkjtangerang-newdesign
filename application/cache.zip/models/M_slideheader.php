<?php
class M_slideheader extends CI_Model{

	function get_all_galeri(){
		// $hsl=$this->db->query("SELECT tbl_galeri.*,DATE_FORMAT(galeri_tanggal,'%d/%m/%Y') AS tanggal,album_nama FROM tbl_galeri join tbl_album on galeri_album_id=album_id ORDER BY galeri_id DESC");
        $hsl=$this->db->query("SELECT tbl_header.*,DATE_FORMAT(tgl_posting,'%d/%m/%Y') AS tanggal FROM tbl_header ORDER BY id_header DESC");
		return $hsl;
	}
	function simpan_galeri($judul,$album,$user_id,$user_nama,$gambar){
		$this->db->trans_start();
            $this->db->query("insert into tbl_galeri(galeri_judul,galeri_album_id,galeri_pengguna_id,galeri_author,galeri_gambar) values ('$judul','$album','$user_id','$user_nama','$gambar')");
            $this->db->query("update tbl_album set album_count=album_count+1 where album_id='$album'");
        $this->db->trans_complete();
        if($this->db->trans_status()==true)
        return true;
        else
        return false;
	}
	
	// function update_galeri($galeri_id,$judul,$album,$user_id,$user_nama,$gambar){
	// 	$hsl=$this->db->query("update tbl_galeri set galeri_judul='$judul',galeri_album_id='$album',galeri_pengguna_id='$user_id',galeri_author='$user_nama',galeri_gambar='$gambar' where galeri_id='$galeri_id'");
	// 	return $hsl;
	// }
	function update_galeri($galeri_id,$judul,$status){
		$hsl=$this->db->query("update tbl_header set judul_header='$judul',status='$status' where id_header='$galeri_id'");
		return $hsl;
	}
	function update_galeri_tanpa_img($galeri_id,$judul,$album,$user_id,$user_nama){
		$hsl=$this->db->query("update tbl_galeri set galeri_judul='$judul',galeri_album_id='$album',galeri_pengguna_id='$user_id',galeri_author='$user_nama' where galeri_id='$galeri_id'");
		return $hsl;
	}
	// function hapus_galeri($kode,$album){
	// 	$this->db->trans_start();
    //         $this->db->query("delete from tbl_galeri where galeri_id='$kode'");
    //         $this->db->query("update tbl_album set album_count=album_count-1 where album_id='$album'");
    //     $this->db->trans_complete();
    //     if($this->db->trans_status()==true)
    //     return true;
    //     else
    //     return false;
	// }
	function hapus_galeri($kode){
		$this->db->trans_start();
        $this->db->query("delete from tbl_header where id_header='$kode'");
        $this->db->trans_complete();
        if($this->db->trans_status()==true)
        return true;
        else
        return false;
	}

	//Front-End
	function get_galeri_home(){
		$hsl=$this->db->query("SELECT tbl_galeri.*,DATE_FORMAT(galeri_tanggal,'%d/%m/%Y') AS tanggal,album_nama FROM tbl_galeri join tbl_album on galeri_album_id=album_id ORDER BY galeri_id DESC limit 4");
		return $hsl;
	}

	function get_galeri_by_album_id($idalbum){
		$hsl=$this->db->query("SELECT tbl_galeri.*,DATE_FORMAT(galeri_tanggal,'%d/%m/%Y') AS tanggal,album_nama FROM tbl_galeri join tbl_album on galeri_album_id=album_id where galeri_album_id='$idalbum' ORDER BY galeri_id DESC");
		return $hsl;
	}
	
	function galeri_perpage($offset,$limit){
		$hsl=$this->db->query("SELECT tbl_galeri.*,DATE_FORMAT(galeri_tanggal,'%d/%m/%Y') AS tanggal,album_nama FROM tbl_galeri join tbl_album on galeri_album_id=album_id ORDER BY galeri_id DESC limit $offset,$limit");
		return $hsl;
	}

	function beritaGetAll(){
      $query="SELECT galeri_gambar FROM tbl_galeri ORDER BY galeri_id DESC limit 3";
      return $this->db->query($query)->result_array();
  	}

  	function get_galeriSlideHome(){
		$hsl=$this->db->query("SELECT tbl_galeri.*,DATE_FORMAT(galeri_tanggal,'%d/%m/%Y') AS tanggal,album_nama FROM tbl_galeri join tbl_album on galeri_album_id=album_id ORDER BY galeri_id DESC limit 3");
		return $hsl;
	}

	function beritaGetAll2(){
      $this->db->select('galeri_gambar');
      $this->db->from('tbl_galeri');
      $this->db->order_by('galeri_tanggal', 'DESC'); // Mengurutkan berdasarkan tanggal terbaru
      $this->db->limit(3); // Ambil hanya 3 gambar
      $query = $this->db->get();
      return $query->result_array();
  	}

  	function headerGetAll(){
		$hsl=$this->db->query("SELECT * FROM tbl_header WHERE status = 1 ORDER BY tgl_posting ASC limit 3");
		return $hsl;
	}

}