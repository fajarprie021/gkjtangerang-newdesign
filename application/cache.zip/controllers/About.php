<?php
class About extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_pengunjung');
		$this->load->model('m_menu');
		$this->load->model('m_profil');
		$this->m_pengunjung->count_visitor();
	}
	function index(){
		$x['tot_guru']=$this->db->get('tbl_guru')->num_rows();
		$x['tot_siswa']=$this->db->get('tbl_siswa')->num_rows();
		$x['tot_files']=$this->db->get('tbl_files')->num_rows();
		$x['tot_agenda']=$this->db->get('tbl_agenda')->num_rows();
		$x['tot_pengumuman']=$this->db->get('tbl_pengumuman')->num_rows();
		$x['menu']=$this->m_menu->get_all_menu();
		$x['alamat']=$this->m_profil->get_alamat();
		$x['tlp']=$this->m_profil->get_tlp();
		$x['email']=$this->m_profil->get_email();
		$x['identitas']=$this->m_profil->get_identitas();
		$this->load->view('depan/v_menu',$x);
		$this->load->view('depan/v_about',$x);
		$this->load->view('depan/v_footer',$x);
	}
}
