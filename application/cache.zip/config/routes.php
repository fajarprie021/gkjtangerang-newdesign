<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home';
$route['administrator']='admin/login';
$route['artikel']='blog';
$route['artikel']='blog/index';
$route['artikel/(:any)']='blog/detail/$1';
// $route['blog']='artikel';
// $route['blog']='artikel/index';
// $route['blog/(:any)']='artikel/detail/$1';
// $route['artikel']='artikel';
// $route['artikel']='artikel/index';
// $route['artikel/(:any)']='artikel/detail/$1';
// $route['blog']='blog';
// $route['blog']='blog/index';
// $route['blog/(:any)']='blog/detail/$1';
// $route['firman']='renungan';
// $route['firman']='renungan/index';
// $route['firman/(:any)']='renungan/detail/$1';
// $route['renungan']='renungan';
// $route['renungan']='renungan/index';
// $route['renungan/(:any)']='renungan/detail/$1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
